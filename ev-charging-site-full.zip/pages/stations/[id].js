import Head from 'next/head'

export default function StationPage({ station, siteUrl }) {
  if (!station) return <div className="max-w-4xl mx-auto p-6">Station not found</div>

  const title = `${station.name} — ${station.type || 'Charging station'}`
  const description = `Visit ${station.name}, operated by ${station.operator || 'unknown'}. ${station.power_kW ? station.power_kW + ' kW' : ''}`

  const ldJson = {
    '@context': 'https://schema.org',
    '@type': 'ChargingStation',
    name: station.name,
    address: station.operator || '',
    geo: { '@type': 'GeoCoordinates', latitude: station.latitude, longitude: station.longitude },
    url: `${siteUrl}/stations/${station.id || station.name}`
  }

  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ldJson) }} />
      </Head>

      <main className="max-w-4xl mx-auto p-6">
        <h1 className="text-2xl font-bold">{station.name}</h1>
        <div className="mt-2 text-sm text-neutral-600">Operator: {station.operator || '—'}</div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-white rounded shadow-sm">
            <div><strong>Type</strong></div>
            <div>{station.type || '—'}</div>
            <div className="mt-2"><strong>Power</strong></div>
            <div>{station.power_kW ? station.power_kW + ' kW' : '—'}</div>
          </div>

          <div className="p-4 bg-white rounded shadow-sm">
            <div><strong>Location</strong></div>
            <div>Lat: {station.latitude}</div>
            <div>Lng: {station.longitude}</div>
            <a className="mt-2 inline-block text-amber-500" href={`https://www.google.com/maps/search/?api=1&query=${station.latitude},${station.longitude}`} target="_blank" rel="noreferrer">Open in Google Maps</a>
          </div>
        </div>

        <div className="mt-6">
          <a className="text-sm text-neutral-500" href="/">← Back to map</a>
        </div>
      </main>
    </>
  )
}

export async function getServerSideProps(context) {
  const { id } = context.params
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || process.env.SITE_URL || 'https://example.com'

  if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY) {
    const { supabaseServer } = await import('../../lib/supabaseServer')
    const { data, error } = await supabaseServer.from('stations').select('*').eq('id', id).limit(1).single()
    if (error) return { props: { station: null, siteUrl } }
    return { props: { station: data, siteUrl } }
  }

  const fs = await import('fs')
  const path = await import('path')
  const jsonPath = path.join(process.cwd(), 'data', 'markers.json')
  if (fs.existsSync(jsonPath)) {
    const raw = fs.readFileSync(jsonPath, 'utf8')
    const markers = JSON.parse(raw || '[]')
    const station = markers.find(m => m.id === id) || markers[Number(id)] || null
    return { props: { station, siteUrl } }
  }

  return { props: { station: null, siteUrl } }
}
