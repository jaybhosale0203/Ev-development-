import fs from 'fs'
import path from 'path'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  try {
    const markers = req.body
    if (!Array.isArray(markers)) return res.status(400).json({ error: 'Expected array' })

    if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY) {
      const { supabaseServer } = await import('../../lib/supabaseServer')
      const toUpsert = markers.map(m => ({
        name: m.name,
        latitude: m.latitude,
        longitude: m.longitude,
        type: m.type || null,
        power_kW: m.power_kW || null,
        operator: m.operator || null,
        metadata: m.metadata || null
      }))
      const { data, error } = await supabaseServer.from('stations').upsert(toUpsert, { onConflict: ['name', 'latitude', 'longitude'] })
      if (error) return res.status(500).json({ error: error.message })
      return res.status(200).json({ ok: true, inserted: data.length })
    }

    const jsonPath = path.join(process.cwd(), 'data', 'markers.json')
    fs.writeFileSync(jsonPath, JSON.stringify(markers, null, 2), 'utf8')
    return res.status(200).json({ ok: true })
  } catch (e) {
    return res.status(500).json({ error: e.message })
  }
}
