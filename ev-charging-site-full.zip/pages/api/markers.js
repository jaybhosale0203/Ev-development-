import fs from 'fs'
import path from 'path'

export default async function handler(req, res) {
  // Try external API
  if (process.env.DATA_API_URL) {
    try {
      const r = await fetch(process.env.DATA_API_URL)
      if (r.ok) {
        const json = await r.json()
        return res.status(200).json(json)
      }
    } catch (e) {}
  }

  const jsonPath = path.join(process.cwd(), 'data', 'markers.json')
  if (fs.existsSync(jsonPath)) {
    try {
      const raw = fs.readFileSync(jsonPath, 'utf8')
      const markers = JSON.parse(raw || '[]')
      return res.status(200).json(markers)
    } catch (e) {}
  }

  const csvPath = path.join(process.cwd(), 'data', 'stations.csv')
  if (fs.existsSync(csvPath)) {
    const { parse } = await import('csv-parse/sync')
    const raw = fs.readFileSync(csvPath, 'utf8')
    const records = parse(raw, { columns: true, skip_empty_lines: true })
    const markers = records.map(r => ({
      name: r.name,
      latitude: parseFloat(r.latitude),
      longitude: parseFloat(r.longitude),
      type: r.type || '',
      power_kW: r.charging_power_kW ? Number(r.charging_power_kW) : null,
      operator: r.operator || ''
    }))
    return res.status(200).json(markers)
  }

  return res.status(200).json([])
}
