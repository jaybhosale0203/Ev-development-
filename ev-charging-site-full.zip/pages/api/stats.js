export default async function handler(req, res) {
  const stats = [{ year: 2018, chargers: 12000 }, { year: 2019, chargers: 18500 }, { year: 2020, chargers: 32000 }, { year: 2021, chargers: 47000 }, { year: 2022, chargers: 69000 }, { year: 2023, chargers: 98000 }, { year: 2024, chargers: 135000 }]
  res.setHeader('Cache-Control', 's-maxage=60, stale-while-revalidate=300')
  res.status(200).json(stats)
}
