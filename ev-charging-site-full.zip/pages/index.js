import Head from 'next/head'
import Image from 'next/image'
import dynamic from 'next/dynamic'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { Bolt } from 'lucide-react'
import { useEffect, useState } from 'react'

const Map = dynamic(() => import('../components/Map'), { ssr: false })

export default function Home({ initialStats, markers, siteMeta }) {
  const [stats, setStats] = useState(initialStats)

  useEffect(() => {
    async function refresh() {
      try {
        const res = await fetch('/api/stats')
        if (res.ok) setStats(await res.json())
      } catch (e) {}
    }
    refresh()
  }, [])

  return (
    <>
      <Head>
        <title>{siteMeta.title}</title>
        <meta name="description" content={siteMeta.description} />
        <meta property="og:title" content={siteMeta.title} />
        <meta property="og:description" content={siteMeta.description} />
        <meta property="og:image" content={siteMeta.ogImage} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          "name": siteMeta.title,
          "url": siteMeta.url,
          "description": siteMeta.description
        }) }} />
      </Head>

      <header className="bg-gradient-to-r from-indigo-50 to-white py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bolt className="w-8 h-8 text-amber-500" />
            <h1 className="font-semibold text-xl">EVChargeHub — smarter charging</h1>
          </div>
          <nav className="text-sm text-neutral-600 hidden md:flex gap-6">
            <a href="#features">Improvements</a>
            <a href="#data">Data</a>
            <a href="#map">Map</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold">Accelerating EV adoption with resilient charging networks</h2>
            <p className="mt-4 text-neutral-600">We design and analyze faster chargers, grid-integration and site planning to scale electric mobility.</p>
            <a href="#contact" className="inline-block mt-6 px-4 py-2 bg-amber-500 text-white rounded-md">Contact us</a>
          </div>
          <div>
            <div className="rounded-lg overflow-hidden shadow-sm">
              <Image src="/images/ev-charging-hero.jpg" alt="EV charging" width={800} height={480} />
            </div>
          </div>
        </section>

        <section id="data" className="mt-12 bg-neutral-50 p-6 rounded-lg">
          <h3 className="font-semibold">Network growth</h3>
          <div className="mt-4 h-64 bg-white rounded-lg p-4">
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={stats}>
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="chargers" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section id="map" className="mt-10">
          <h3 className="font-semibold">Charging hubs map</h3>
          <div className="mt-4 h-96 rounded-lg overflow-hidden">
            <Map initialMarkers={markers} />
          </div>
        </section>

      </main>

      <footer className="bg-neutral-900 text-white py-6">
        <div className="max-w-6xl mx-auto px-6 text-sm">© {new Date().getFullYear()} EVChargeHub</div>
      </footer>
    </>
  )
}

export async function getServerSideProps() {
  const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com'
  const siteMeta = {
    title: 'EVChargeHub — Charging infrastructure research & deployment',
    description: 'Resources, data and tools to plan and deploy robust EV charging networks.',
    url: SITE_URL,
    ogImage: `${SITE_URL}/images/og-ev-charging.png`
  }

  let initialStats = [{ year: 2018, chargers: 12000 }, { year: 2019, chargers: 18500 }, { year: 2020, chargers: 32000 }, { year: 2021, chargers: 47000 }, { year: 2022, chargers: 69000 }, { year: 2023, chargers: 98000 }]
  let markers = []
  try {
    const r = await fetch(process.env.DATA_API_URL || `${SITE_URL}/api/markers`)
    if (r.ok) {
      const json = await r.json()
      if (json.stats) initialStats = json.stats
      if (Array.isArray(json)) markers = json
    }
  } catch (e) {}

  return { props: { initialStats, markers, siteMeta } }
}
