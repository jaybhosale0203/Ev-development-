import { useState } from 'react'
import Papa from 'papaparse'

export default function Upload() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState([])
  const [status, setStatus] = useState('')

  function handleFile(e) {
    const f = e.target.files[0]
    setFile(f)
    Papa.parse(f, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setPreview(results.data.map(r => ({
          name: r.name,
          latitude: parseFloat(r.latitude),
          longitude: parseFloat(r.longitude),
          type: r.type,
          power_kW: r.charging_power_kW ? Number(r.charging_power_kW) : null,
          operator: r.operator
        })))
      }
    })
  }

  async function submit() {
    setStatus('Uploading...')
    try {
      const res = await fetch('/api/import-markers', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(preview) })
      if (res.ok) {
        setStatus('Imported successfully')
      } else {
        setStatus('Upload failed')
      }
    } catch (e) {
      setStatus('Error: ' + e.message)
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-xl font-semibold">Admin — Import stations CSV</h2>
      <p className="mt-2 text-sm text-neutral-600">CSV must have headers: name,latitude,longitude,type,charging_power_kW,operator</p>
      <input type="file" accept="text/csv" onChange={handleFile} className="mt-4" />

      {preview.length > 0 && (
        <div className="mt-4">
          <div className="text-sm mb-2">Preview ({preview.length} rows)</div>
          <div className="bg-white p-3 rounded shadow-sm max-h-60 overflow-auto">
            <table className="w-full text-sm">
              <thead><tr><th className="text-left">Name</th><th>Lat</th><th>Lng</th><th>Type</th><th>kW</th><th>Operator</th></tr></thead>
              <tbody>
                {preview.slice(0, 50).map((r,i)=> (
                  <tr key={i}><td>{r.name}</td><td>{r.latitude}</td><td>{r.longitude}</td><td>{r.type}</td><td>{r.power_kW}</td><td>{r.operator}</td></tr>
                ))}
              </tbody>
            </table>
          </div>

          <button onClick={submit} className="mt-4 px-4 py-2 bg-amber-500 text-white rounded">Import to site</button>
          <div className="mt-2 text-sm text-neutral-600">{status}</div>
        </div>
      )}
    </div>
  )
}
