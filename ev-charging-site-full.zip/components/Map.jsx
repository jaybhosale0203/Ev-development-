import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import MapGL, { Popup, NavigationControl, Source, Layer } from 'react-map-gl'

const clusterLayer = {
  id: 'clusters',
  type: 'circle',
  source: 'stations',
  filter: ['has', 'point_count'],
  paint: {
    'circle-color': ['step', ['get', 'point_count'], '#51bbd6', 10, '#f1f075', 30, '#f28cb1'],
    'circle-radius': ['step', ['get', 'point_count'], 15, 10, 20, 30, 25]
  }
}

const clusterCountLayer = {
  id: 'cluster-count',
  type: 'symbol',
  source: 'stations',
  filter: ['has', 'point_count'],
  layout: {
    'text-field': ['get', 'point_count_abbreviated'],
    'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
    'text-size': 12
  }
}

const unclusteredPointLayer = {
  id: 'unclustered-point',
  type: 'circle',
  source: 'stations',
  filter: ['!', ['has', 'point_count']],
  paint: {
    'circle-color': '#ff7e1a',
    'circle-radius': 7,
    'circle-stroke-width': 2,
    'circle-stroke-color': '#fff'
  }
}

export default function Map({ initialMarkers = [] }) {
  const [viewport, setViewport] = useState({ longitude: initialMarkers[0]?.longitude || -122.4194, latitude: initialMarkers[0]?.latitude || 37.7749, zoom: 10 })
  const [markers, setMarkers] = useState(initialMarkers)
  const [popupInfo, setPopupInfo] = useState(null)
  const mapRef = useRef()
  const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN || ''

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/markers')
        if (res.ok) setMarkers(await res.json())
      } catch (e) {}
    }
    load()
  }, [])

  const geojson = useMemo(() => ({
    type: 'FeatureCollection',
    features: markers.map(m => ({ type: 'Feature', properties: m, geometry: { type: 'Point', coordinates: [m.longitude, m.latitude] } }))
  }), [markers])

  const onClick = useCallback((event) => {
    const feature = event.features && event.features[0]
    if (!feature) return
    const clusterId = feature.properties.cluster_id
    const map = mapRef.current
    if (clusterId) {
      map.getMap().getSource('stations').getClusterExpansionZoom(clusterId, (err, zoom) => {
        if (err) return
        setViewport(v => ({ ...v, longitude: feature.geometry.coordinates[0], latitude: feature.geometry.coordinates[1], zoom }))
      })
    } else {
      setPopupInfo({ longitude: feature.geometry.coordinates[0], latitude: feature.geometry.coordinates[1], properties: feature.properties })
    }
  }, [])

  return (
    <MapGL
      ref={mapRef}
      mapboxAccessToken={MAPBOX_TOKEN}
      initialViewState={viewport}
      mapStyle="mapbox://styles/mapbox/streets-v11"
      interactiveLayerIds={[clusterLayer.id, unclusteredPointLayer.id]}
      onMove={evt => setViewport(evt.viewState)}
      style={{ width: '100%', height: '100%' }}
      onClick={onClick}
    >
      <Source id="stations" type="geojson" data={geojson} cluster={true} clusterMaxZoom={14} clusterRadius={50}>
        <Layer {...clusterLayer} />
        <Layer {...clusterCountLayer} />
        <Layer {...unclusteredPointLayer} />
      </Source>

      <div style={{ position: 'absolute', right: 12, top: 12 }}>
        <NavigationControl />
      </div>

      {popupInfo && (
        <Popup anchor="bottom" longitude={popupInfo.longitude} latitude={popupInfo.latitude} onClose={() => setPopupInfo(null)}>
          <div style={{ minWidth: 160 }}>
            <strong>{popupInfo.properties.name}</strong>
            <div style={{ fontSize: 12 }}>{popupInfo.properties.type} — {popupInfo.properties.power_kW || 'n/a'} kW</div>
            <div style={{ fontSize: 12, color: '#666' }}>{popupInfo.properties.operator}</div>
            <div style={{ marginTop: 6 }}><a href={`/stations/${popupInfo.properties.id || popupInfo.properties.name}`} className="text-amber-600">View details</a></div>
          </div>
        </Popup>
      )}
    </MapGL>
  )
}
