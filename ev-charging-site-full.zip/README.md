# EV Charging Site — Next.js + Supabase + Mapbox

This project is a complete Next.js application showcasing EV charging infrastructure, with Mapbox map integration, Supabase persistence, SSR pages, CSV importer, and SEO optimizations.

## Setup (local)

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.local.sample` to `.env.local` and fill in your keys.
3. Run locally:
   ```bash
   npm run dev
   ```
4. Visit http://localhost:3000

## Deploy

Recommended: Vercel (connect GitHub repo and set environment variables).
