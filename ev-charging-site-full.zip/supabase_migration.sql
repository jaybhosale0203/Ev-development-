-- Supabase SQL migration for 'stations' table
create extension if not exists "uuid-ossp";

create table if not exists public.stations (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  latitude double precision not null,
  longitude double precision not null,
  type text,
  power_kW int,
  operator text,
  metadata jsonb,
  created_at timestamptz default now()
);
